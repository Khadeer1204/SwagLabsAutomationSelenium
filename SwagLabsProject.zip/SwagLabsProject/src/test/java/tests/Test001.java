package tests;

import base.BaseTest;
import pages.CartPage;
import pages.CheckoutPage;
import pages.ConfirmationPage;
import pages.LoginPage;
import pages.ProductsPage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test001 extends BaseTest {

    @Test
    public void endToEndSwagLabsTest() {
        LoginPage login = new LoginPage(driver);
        login.login("standard_user", "secret_sauce");

        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));

        ProductsPage products = new ProductsPage(driver);
        products.sortBy("Name (Z to A)");

        List<String> sortedNames = products.getProductNames();
        List<String> expected = new ArrayList<>(sortedNames);
        Collections.sort(expected, Collections.reverseOrder());
        Assert.assertEquals(sortedNames, expected);

        products.addFirstProductToCart();

        CartPage cart = new CartPage(driver);
        cart.openCart();
        Assert.assertFalse(cart.getCartItemName().isEmpty());

        CheckoutPage checkout = new CheckoutPage(driver);
        checkout.startCheckout("Karim", "Basha", "516115");
        String price = checkout.getTotalPrice();
        Assert.assertTrue(price.contains("$"));

        checkout.finishOrder();

        ConfirmationPage confirm = new ConfirmationPage(driver);
        Assert.assertEquals(confirm.getConfirmationMessage(), "Thank you for your order!");
    }
}