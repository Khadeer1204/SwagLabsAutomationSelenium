package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test002 extends BaseTest {

    @Test
    public void verifyHomePagePresence() {
        String title = driver.getTitle();
        String url = driver.getCurrentUrl();

        Assert.assertTrue(title.contains("Swag Labs"));
        Assert.assertTrue(url.contains("saucedemo"));
    }
}