package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import base.DriverFactory;
import utilities.ConfigReader;


public class BaseTest {
    public WebDriver driver;
    protected ExtentReports extent;
    protected ExtentTest test;

    @BeforeClass
    public void setup() {
        ConfigReader.loadConfig();
        extent = ExtentManager.getInstance();

        String browser = ConfigReader.get("browser");
        String url = ConfigReader.get("url");

        driver = DriverFactory.getDriver(browser);
        driver.get(url);
        driver.manage().window().maximize();

    }

    @AfterClass
    public void tearDown() {
        DriverFactory.quitDriver();
    }
    public void captureScreenshot(String name) {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            Files.copy(src.toPath(), Paths.get("reports/screenshots/" + name + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}