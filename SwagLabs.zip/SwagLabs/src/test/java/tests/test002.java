package tests;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.LoginPage;
import pojo.LoginData;
import utilis.ConfigReader;
import utilis.ExcelReader;

public class test002 extends BaseClass{
	
    @Test
    public void urls() {

   	 ConfigReader.loadConfig();
      String path = ConfigReader.get("excelFilePath");
      String sheet = ConfigReader.get("sheetName");  
    	 List<LoginData> loginDataList = ExcelReader.getLoginData(path, sheet);
         
         LoginData credentials = loginDataList.get(0);
         
         String username = credentials.getUsername();
         String password = credentials.getPassword();
  
         LoginPage login = new LoginPage(driver);
        login.login(username, password);
        
          
       
       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
       
       List<WebElement> ele = driver.findElements(By.xpath("//a"));
       
       for(WebElement el : ele) {
    	   
    	   
			System.out.println(el.getText());
		}
       }
        
    
    }


