package tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import baseClass.BaseClass;
import pages.CartPage;
import pages.CheckoutPage;
import pages.ConfirmationPage;
import pages.LoginPage;
import pages.ProductsPage;
import utilis.ConfigReader;
import pojo.LoginData;
import utilis.ExcelReader;
public class test001 extends BaseClass {

    @Test
    public void endToEndSwagLabsTest() {
       
    	 ConfigReader.loadConfig();
       String path = ConfigReader.get("excelFilePath");
       String sheet = ConfigReader.get("sheetName");
        
        test = extent.createTest("test001");
        
        List<LoginData> loginDataList = ExcelReader.getLoginData(path, sheet);
        
         LoginData credentials = loginDataList.get(0);
         
         String username = credentials.getUsername();
         String password = credentials.getPassword();
  
         LoginPage login = new LoginPage(driver);
        login.login(username, password);
        
        
        
        String expectedTitle = "Swag Labs";
        String title = driver.getTitle();
        Assert.assertEquals(title, expectedTitle, "Title mismatch.");
        if( title.equals(expectedTitle)) {
        	
        	captureScreenshot( title);
        	
        }
        test.log(Status.PASS, "Title validation passed. Actual: " + driver.getTitle());
        
        String expectedurl = "https://www.saucedemo.com/inventory.html";
        String url=driver.getCurrentUrl();
        Assert.assertTrue(url.contains("inventory"));
        
        if(url.equals(expectedurl)) {
        	captureScreenshot("CurrentURL");
        }
        test.log(Status.PASS, "Successfully logged in with standard_user.");
        
        
        ProductsPage products = new ProductsPage(driver);
        products.sortBy("Name (Z to A)");

        List<String> sortedNames = products.getProductNames();
        List<String> expected = new ArrayList<>(sortedNames);
        Collections.sort(expected, Collections.reverseOrder());
        
        Assert.assertEquals(sortedNames, expected);
        
        test.log(Status.PASS, "Sorted in Z to A order");
      
        

        products.addFirstProductToCart();

        CartPage cart = new CartPage(driver);
        cart.openCart();
        Assert.assertFalse(cart.getCartItemName().isEmpty());
        test.log(Status.PASS, "Succesfully added to the cart");
        

        CheckoutPage checkout = new CheckoutPage(driver);
        
        String fname  = ConfigReader.get("fname");
        String lname  = ConfigReader.get("lname");
        String pincode  = ConfigReader.get("pinCode");
        checkout.startCheckout(fname, lname, pincode);
        String price = checkout.getTotalPrice();
        Assert.assertTrue(price.contains("$"));

        checkout.finishOrder();

        ConfirmationPage confirm = new ConfirmationPage(driver);
        Assert.assertEquals(confirm.getConfirmationMessage(), "Thank you for your order!");
        test.log(Status.PASS, "Order completion validation passed. Message: Thank you for your order!"  );	
    }
}