package utilis;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import pojo.LoginData;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

    public static List<LoginData> getLoginData(String filePath, String sheetName) {
        List<LoginData> dataList = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getPhysicalNumberOfRows();

            for (int i = 1; i < rowCount; i++) { // Start from 1 to skip header
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String username = row.getCell(0).getStringCellValue();
                String password = row.getCell(1).getStringCellValue();

                dataList.add(new LoginData(username, password));
            }

        } catch (IOException e) {
            System.out.println("Error reading Excel file: " + e.getMessage());
            e.printStackTrace();
        }

        return dataList;
    }
}