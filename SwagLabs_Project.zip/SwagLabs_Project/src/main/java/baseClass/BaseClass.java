package baseClass;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import driverFactory.DriverFactory;

import utilis.ConfigReader;

public class BaseClass {
	
	 public  WebDriver driver;
	    protected  ExtentReports extent;
	    protected  ExtentTest test;
	
	    @BeforeSuite
	    public void setupExtentReport() {
	    	 ConfigReader.loadConfig();
	    	extent = ExtentManager.getInstance();
	        
	    }
	@BeforeClass
	public void launchBrowser() {
		 		    
	        String browser = ConfigReader.get("browser");
	        String url = ConfigReader.get("url");
	        driver = DriverFactory.getDriver(browser);
	        
	        
	      
	        driver.manage().window().maximize();
	        
	       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
          
	       driver.get(url);
		
	}
	
	
	
	@AfterClass
	public void closeBrowser() {
		
		driver.close();
	}
	  public  void captureScreenshot( String name) {
		 
	       File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
	        try {
	            Files.copy(src.toPath(), Paths.get("reports/screenshots/" + name + ".png"));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	  @AfterSuite
      public void tearDownReport() {
          if(extent != null) {
        	  extent.flush();
          }
      }

}
