package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.stream.Collectors;

public class ProductsPage {
    private WebDriver driver;

    private By sortDropdown = By.className("product_sort_container");
    private By productNames = By.className("inventory_item_name");
    private By addToCartBtn = By.xpath("(//button[text()='Add to cart'])[1]");
  

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void sortBy(String visibleText) {
        new Select(driver.findElement(sortDropdown)).selectByVisibleText(visibleText);
    }

    public List<String> getProductNames() {
        return driver.findElements(productNames).stream()
                     .map(WebElement::getText)
                     .collect(Collectors.toList());
    }
     
    public void addFirstProductToCart() {
        driver.findElement(addToCartBtn).click();
    }
    
 
 
    
    
}


