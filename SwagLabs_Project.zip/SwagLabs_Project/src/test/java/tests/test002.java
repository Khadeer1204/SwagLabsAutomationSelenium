
package tests;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import baseClass.BaseClass;
import pages.LoginPage;
import pojo.LoginData;
import utilis.ConfigReader;
import utilis.ExcelReader;



public class test002 extends BaseClass {

    @Test
    public void urls() {
         

     ExtentReports extent = new ExtentReports();
     ExtentTest test = extent.createTest("My Test Case");

        ConfigReader.loadConfig();
        String path = ConfigReader.get("excelFilePath");
        String sheet = ConfigReader.get("sheetName");

        List<LoginData> loginDataList = ExcelReader.getLoginData(path, sheet);

        LoginData credentials = loginDataList.get(0);

        String username = credentials.getUsername();
        String password = credentials.getPassword();

        test = extent.createTest("Extract All URLs After Login");

        LoginPage login = new LoginPage(driver);
        login.login(username, password);
        test.log(Status.INFO, "Logged in with username: " + username);

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        List<WebElement> ele = driver.findElements(By.xpath("//a"));

        test.log(Status.INFO, "Total links found: " + ele.size());

        for (WebElement el : ele) {
            String linkText = el.getText();
            String href = el.getAttribute("href");
            test.log(Status.INFO, "Link Text: " + linkText + " | URL: " + href);
            System.out.println(linkText);
        }

      test.log(Status.PASS, "All URLs extracted and logged successfully.");
    }
}
