
package tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import baseClass.BaseClass;
import pages.CartPage;
import pages.CheckoutPage;
import pages.ConfirmationPage;
import pages.LoginPage;
import pages.ProductsPage;
import pojo.LoginData;
import utilis.ConfigReader;
import utilis.ExcelReader;

public class test001 extends BaseClass {

    @Test
    public void endToEndSwagLabsTest() {

        ConfigReader.loadConfig();
        String path = ConfigReader.get("excelFilePath");
        String sheet = ConfigReader.get("sheetName");
        String url = ConfigReader.get("url");
        List<LoginData> loginDataList = ExcelReader.getLoginData(path, sheet);

       LoginData validCredentials = null;
       LoginPage login = new LoginPage(driver);
        for (LoginData credentials : loginDataList) {
            String username = credentials.getUsername();
            String password = credentials.getPassword();

            test = extent.createTest("Login Attempt: " + username);
          
            login.login(username, password);

            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains("inventory")) {
                test.log(Status.PASS, "Login successful for: " + username);
                captureScreenshot("LoginSuccess_" + username);
                driver.navigate().to(url);
                if (username.equals("standard_user") && password.equals("secret_sauce")) {
                    validCredentials = credentials;
                }
            } else {
                test.log(Status.FAIL, "Login failed for: " + username);
                captureScreenshot("LoginFailed_" + username);
                WebElement userField = driver.findElement(By.id("user-name"));
                WebElement passField = driver.findElement(By.id("password"));
                userField.clear();
                passField.clear();
            }
        }

        if (validCredentials != null) {
            test = extent.createTest("Final Login with Valid Credentials");
            login.login(validCredentials.getUsername(), validCredentials.getPassword());

            String expectedTitle = "Swag Labs";
            String actualTitle = driver.getTitle();
            Assert.assertEquals(actualTitle, expectedTitle, "Title mismatch.");
            test.log(Status.PASS, "Title validation passed. Actual: " + actualTitle);
            captureScreenshot("Title_" + actualTitle);

            //String expectedUrl = "https://www.saucedemo.com/inventory.html";
            String actualUrl = driver.getCurrentUrl();
            Assert.assertTrue(actualUrl.contains("inventory"));
            test.log(Status.PASS, "Successfully logged in with standard_user.");
            captureScreenshot("InventoryPage");

            ProductsPage products = new ProductsPage(driver);
            products.sortBy("Name (Z to A)");

            List<String> sortedNames = products.getProductNames();
            List<String> expectedSorted = new ArrayList<>(sortedNames);
            Collections.sort(expectedSorted, Collections.reverseOrder());

            Assert.assertEquals(sortedNames, expectedSorted);
            test.log(Status.PASS, "Products sorted in Z to A order.");

            products.addFirstProductToCart();

            CartPage cart = new CartPage(driver);
            cart.openCart();
            Assert.assertFalse(cart.getCartItemName().isEmpty());
            test.log(Status.PASS, "Product successfully added to cart.");

            CheckoutPage checkout = new CheckoutPage(driver);
            String fname = ConfigReader.get("fname");
            String lname = ConfigReader.get("lname");
            String pincode = ConfigReader.get("pinCode");

            checkout.startCheckout(fname, lname, pincode);
            String price = checkout.getTotalPrice();
            Assert.assertTrue(price.contains("$"));
            test.log(Status.PASS, "Total price captured: " + price);

            checkout.finishOrder();

            ConfirmationPage confirm = new ConfirmationPage(driver);
            String confirmationMsg = confirm.getConfirmationMessage();
            Assert.assertEquals(confirmationMsg, "Thank you for your order!");
            test.log(Status.PASS, "Order completed. Message: " + confirmationMsg);
        } else {
            test = extent.createTest("Valid Credentials Missing");
            test.log(Status.FAIL, "No valid credentials found in Excel.");
        }
    }
}
